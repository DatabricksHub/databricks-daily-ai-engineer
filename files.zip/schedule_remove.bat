@echo off
REM Remove the AMPERE scheduled task
SCHTASKS /DELETE /TN "AMPERE_DatabricksAIEngineer" /F
IF %ERRORLEVEL% EQU 0 (
    echo [SUCCESS] AMPERE task removed from Task Scheduler.
) ELSE (
    echo [INFO] Task was not found or already removed.
)
pause
