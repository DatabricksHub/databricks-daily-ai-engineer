@echo off
REM ============================================================
REM  AMPERE — Daily Run Wrapper
REM  Used by Task Scheduler. Logs output to logs\YYYYMMDD.log
REM ============================================================

SET PROJECT_DIR=%~dp0
SET PYTHON=%PROJECT_DIR%venv\Scripts\python.exe
IF NOT EXIST "%PYTHON%" (
    FOR /F "tokens=*" %%i IN ('where python') DO SET PYTHON=%%i
)

REM Create logs directory
IF NOT EXIST "%PROJECT_DIR%logs" MKDIR "%PROJECT_DIR%logs"

REM Date-stamped log file
FOR /F "tokens=1-3 delims=/ " %%a IN ("%DATE%") DO (
    SET LOG_DATE=%%c%%a%%b
)
SET LOG_FILE=%PROJECT_DIR%logs\%LOG_DATE%.log

REM Change to project directory so .env is found
CD /D "%PROJECT_DIR%"

echo ============================================ >> "%LOG_FILE%"
echo AMPERE run started: %DATE% %TIME%           >> "%LOG_FILE%"
echo ============================================ >> "%LOG_FILE%"

"%PYTHON%" "%PROJECT_DIR%main.py" >> "%LOG_FILE%" 2>&1

IF %ERRORLEVEL% EQU 0 (
    echo Run completed successfully: %TIME% >> "%LOG_FILE%"
) ELSE (
    echo Run FAILED with error code %ERRORLEVEL%: %TIME% >> "%LOG_FILE%"
)
echo. >> "%LOG_FILE%"
