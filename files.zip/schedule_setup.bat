@echo off
REM ============================================================
REM  AMPERE — Windows Task Scheduler Setup
REM  Run ONCE as Administrator to register the daily 6am task
REM  Right-click -> Run as administrator
REM ============================================================

SET TASK_NAME=AMPERE_DatabricksAIEngineer
SET PROJECT_DIR=%~dp0
SET WRAPPER=%PROJECT_DIR%run_scheduled.bat

echo.
echo === AMPERE Task Scheduler Setup ===
echo Project folder : %PROJECT_DIR%
echo Wrapper script : %WRAPPER%
echo Schedule       : Daily at 06:00 AM
echo Logs saved to  : %PROJECT_DIR%logs\YYYYMMDD.log
echo.

REM Remove existing task cleanly
SCHTASKS /DELETE /TN "%TASK_NAME%" /F >nul 2>&1

REM Create task — runs run_scheduled.bat which logs output
SCHTASKS /CREATE ^
  /TN "%TASK_NAME%" ^
  /TR "cmd /c \"%WRAPPER%\"" ^
  /SC DAILY ^
  /ST 06:00 ^
  /RU "%USERNAME%" ^
  /RL HIGHEST ^
  /F ^
  /IT

IF %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Scheduled task created.
    echo.
    echo AMPERE will run automatically every day at 06:00 AM.
    echo Output logs will be saved to: %PROJECT_DIR%logs\
    echo.
    echo Useful commands:
    echo   Check status : SCHTASKS /QUERY /TN "%TASK_NAME%" /FO LIST /V
    echo   Run now      : SCHTASKS /RUN   /TN "%TASK_NAME%"
    echo   Remove task  : SCHTASKS /DELETE /TN "%TASK_NAME%" /F
    echo   View log     : notepad "%PROJECT_DIR%logs\<YYYYMMDD>.log"
    echo.
) ELSE (
    echo.
    echo [ERROR] Could not create task.
    echo Make sure you right-clicked and chose "Run as administrator".
    echo.
)

pause
